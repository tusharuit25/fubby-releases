# Fubby Integrated Developer Preview

This local-only application combines the Core built-ins, Moon SQLite and HTTP,
Snow routing/static files, Bela request-scoped tasks/channels, Shady tooling, and
Smokey path packages. It is a developer preview, not a production deployment.

From a clean checkout (with a Rust toolchain):

```sh
cargo build --release
cd examples/milestone17/app
../../../target/release/fubby pkg validate
../../../target/release/fubby pkg install
../../../target/release/fubby shady test tests
../../../target/release/fubby snow serve src/main.fab --port 8080 --workers 4 --queue-capacity 32 --shutdown-file /tmp/fubby-preview.stop
```

Open `http://127.0.0.1:8080/`. The default upstream diagnostic intentionally
uses a refused local port; the handler catches and reports that error. To run
the successful Moon HTTP round trip, use the automated smoke test, which
substitutes a temporary localhost mock and sets `FUBBY_NET_ALLOWLIST=127.0.0.1`.

The app has Home, About, and Runtime pages; JSON notes CRUD; request-isolation
probes; a bounded Bela worker/channel path for title normalization; and static
CSS/JavaScript. `preview-kit` is a local Smokey package dependency.

```sh
../../../target/release/fubby snow stop /tmp/fubby-preview.stop
```

Choose an absent shutdown-marker path for each server run. The automated
acceptance script uses a temporary checkout, registry-free dependency install,
isolated database, ephemeral server/upstream ports, concurrent requests, and
graceful shutdown; it leaves no demo database in this source tree.
