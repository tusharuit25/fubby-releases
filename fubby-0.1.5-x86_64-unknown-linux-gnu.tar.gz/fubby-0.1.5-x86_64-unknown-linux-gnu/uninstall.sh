#!/bin/sh
set -eu

usage() {
    echo "Usage: $0 [--prefix PATH]" >&2
    exit 2
}

prefix="${FUBBY_PREFIX:-${HOME:?HOME must be set}/.local}"
if [ "$#" -eq 2 ] && [ "$1" = "--prefix" ]; then
    prefix=$2
elif [ "$#" -ne 0 ]; then
    usage
fi
case "$prefix" in
    ""|/|/usr|/usr/*|/bin|/sbin|/System|/System/*|/Library|/Library/*)
        echo "Refusing unsafe install prefix: $prefix" >&2
        exit 1
        ;;
    /*) ;;
    *) prefix="$PWD/$prefix" ;;
esac
if [ -L "$prefix" ]; then
    echo "Refusing symlink install prefix: $prefix" >&2
    exit 1
fi
if [ ! -d "$prefix" ]; then
    echo "Install prefix does not exist: $prefix" >&2
    exit 1
fi
prefix=$(CDPATH= cd -P "$prefix" && pwd)
case "$prefix" in
    /|/usr|/usr/*|/bin|/sbin|/System|/System/*|/Library|/Library/*)
        echo "Refusing unsafe resolved install prefix: $prefix" >&2
        exit 1
        ;;
esac
bin_dir="$prefix/bin"
if [ -L "$bin_dir" ]; then
    echo "Refusing symlink install directory: $bin_dir" >&2
    exit 1
fi
destination="$bin_dir/fubby"
if [ -L "$destination" ]; then
    echo "Refusing to remove symlink: $destination" >&2
    exit 1
fi
if [ -f "$destination" ]; then
    rm -f "$destination"
    echo "Removed $destination"
else
    echo "Fubby is not installed at $destination"
fi
