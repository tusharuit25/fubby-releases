# Fubby Developer Preview installation

Fubby is proprietary software. `LICENSE.txt` in this bundle sets the terms for using
and redistributing it, and `THIRD_PARTY_NOTICES.txt` lists its open-source components.

## Windows

Windows support is a beta. This build was made on a Mac, and hadn't been run on a real
Windows PC when it was published. The Windows bundle is a zip file, and needs Windows 10
or later. Extract it, then run this in
PowerShell from the extracted folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1
fubby --version
```

Open a new terminal if `fubby` isn't found. The installer uses
`%LOCALAPPDATA%\Programs\Fubby`, adds its `bin` folder to your user PATH, and never needs
administrator rights. Pass `-Prefix` to choose another folder, or `-NoPath` to leave PATH
alone. Run `uninstall.ps1` the same way to remove it. The binary isn't signed yet, so
Windows may show a SmartScreen warning.

The rest of this guide describes macOS and Linux.

## macOS and Linux

This guide installs a local binary bundle without a compiler or administrator
privileges. The verified Milestone 19 archive target is **macOS x86-64
(Intel)**. Archives for other Rust targets are marked unverified until built
and smoke-tested on that target. This preview is experimental.

## Verify and unpack

From a trusted download directory, verify the sidecar checksum before
extracting. On macOS:

```sh
shasum -a 256 -c fubby-0.1.5-x86_64-apple-darwin.tar.gz.sha256
tar -xzf fubby-0.1.5-x86_64-apple-darwin.tar.gz
```

Check `release-manifest.json` for the target, version and known limitations.
The checksum detects archive corruption when the checksum file is trusted; it
is not a signature and does not authenticate who built the archive.

## Install for the current user

```sh
cd fubby-0.1.5-x86_64-apple-darwin
./install.sh
"$HOME/.local/bin/fubby" --version
```

The installer copies only the executable to `~/.local/bin/fubby`. It does not
invoke `sudo`. If `~/.local/bin` is not on `PATH`, add it in your shell profile:

```sh
export PATH="$HOME/.local/bin:$PATH"
```

Choose another user-owned prefix with `./install.sh --prefix "$HOME/tools"`.
The installer rejects system prefixes and symlink destinations rather than
elevating privileges or following a binary symlink. Installation replaces a
regular existing `fubby` executable atomically. Remove the installed binary
with `./uninstall.sh` using the same prefix.

## Try the included starter project

The archive includes a small Fubby project demonstrating Core, Moon HTTP and
SQLite, Shady tests/format/lint/profile, Snow pages and REST, Bela request
tasks, and a local Smokey package. It contains sample `.fab` application source;
the Rust implementation source is not included.

```sh
cd starter-project/app
"$HOME/.local/bin/fubby" pkg validate
"$HOME/.local/bin/fubby" pkg install
"$HOME/.local/bin/fubby" check src/main.fab
"$HOME/.local/bin/fubby" shady test tests/preview_tests.fab
"$HOME/.local/bin/fubby" shady fmt --check src/main.fab
"$HOME/.local/bin/fubby" shady lint src/main.fab
"$HOME/.local/bin/fubby" snow serve src/main.fab --port 8080 --workers 4 --queue-capacity 32 --shutdown-file /tmp/fubby-preview.stop
```

Open `http://127.0.0.1:8080/`. Stop the server from another shell with
`"$HOME/.local/bin/fubby" snow stop /tmp/fubby-preview.stop`. The app creates
`preview.db` and `.fubby/` in its working directory. Use a disposable copy if
you want to preserve the starter files.

## Checkout-independent smoke test

An optional Python 3 standard-library smoke runner is included in the archive.
It tests the installed executable, not a binary in the source checkout, while
running from a temporary application copy and unrelated current directory:

```sh
cd /tmp
python3 /path/to/fubby-0.1.5-x86_64-apple-darwin/smoke_test.py \
  "$HOME/.local/bin/fubby" \
  /path/to/fubby-0.1.5-x86_64-apple-darwin/starter-project
```

It checks `--version`, project initialization, local package validation and
installation, Shady test/format/lint/profile, web pages and static assets,
SQLite CRUD, 48 concurrent request-isolation probes, and graceful shutdown.
The runner uses only Python's standard library and bundled files. The test is
isolated from the source checkout but runs on the current host; it is not a
physical clean-machine or other-architecture test.

## Uninstall

```sh
cd fubby-0.1.5-x86_64-apple-darwin
./uninstall.sh
```

For a custom prefix, pass the same `--prefix "$HOME/tools"` used at install.
Uninstall removes only `bin/fubby`; it leaves user data and directories alone.

## Build from the private source checkout

The repository pins Rust 1.98.1 in `rust-toolchain.toml`, declares Rust 1.88 as
the minimum compatible compiler, and commits `Cargo.lock`. With the pinned
toolchain and dependencies available locally:

```sh
cargo build --locked --release
```

To create a local archive for the current host target (requires Python 3.10 or
newer):

```sh
python3 scripts/package_release.py package --output dist
python3 scripts/package_release.py verify \
  dist/fubby-0.1.5-x86_64-apple-darwin.tar.gz \
  --checksum dist/fubby-0.1.5-x86_64-apple-darwin.tar.gz.sha256
```

`dist/` is ignored by Git. Do not put this private checkout, Rust source, or
unreviewed build artifacts in a public binary-download repository. No release
upload or publication is performed by these commands.

## Security limits

Do not run untrusted `.fab` programs. Fubby has no OS sandbox, hard OS heap
quota, application authentication, or publisher authentication. Runtime memory
accounting is approximate. See `MILESTONE18.md` and the release manifest for
the current limitations.
