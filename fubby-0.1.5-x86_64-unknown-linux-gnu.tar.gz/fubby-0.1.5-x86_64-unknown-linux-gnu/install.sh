#!/bin/sh
set -eu

usage() {
    echo "Usage: $0 [--prefix PATH]" >&2
    exit 2
}

prefix="${FUBBY_PREFIX:-${HOME:?HOME must be set}/.local}"
if [ "$#" -eq 2 ] && [ "$1" = "--prefix" ]; then
    prefix=$2
elif [ "$#" -ne 0 ]; then
    usage
fi
case "$prefix" in
    ""|/|/usr|/usr/*|/bin|/sbin|/System|/System/*|/Library|/Library/*)
        echo "Refusing unsafe install prefix: $prefix" >&2
        exit 1
        ;;
esac
case "$prefix" in
    /*) ;;
    *) prefix="$PWD/$prefix" ;;
esac
if [ -L "$prefix" ]; then
    echo "Refusing symlink install prefix: $prefix" >&2
    exit 1
fi

case "$0" in
    */*) script_directory=${0%/*} ;;
    *) script_directory=. ;;
esac
script_dir=$(CDPATH= cd -P "$script_directory" && pwd)
if [ -L "$script_dir/bin" ] || [ ! -d "$script_dir/bin" ]; then
    echo "Bundle bin directory is missing or is a symlink: $script_dir/bin" >&2
    exit 1
fi
source_binary="$script_dir/bin/fubby"
if [ -L "$source_binary" ] || [ ! -f "$source_binary" ]; then
    echo "Bundle executable is missing or is a symlink: $source_binary" >&2
    exit 1
fi

mkdir -p "$prefix"
prefix=$(CDPATH= cd -P "$prefix" && pwd)
case "$prefix" in
    /|/usr|/usr/*|/bin|/sbin|/System|/System/*|/Library|/Library/*)
        echo "Refusing unsafe resolved install prefix: $prefix" >&2
        exit 1
        ;;
esac
bin_dir="$prefix/bin"
if [ -L "$bin_dir" ]; then
    echo "Refusing symlink install directory: $bin_dir" >&2
    exit 1
fi
mkdir -p "$bin_dir"
bin_dir=$(CDPATH= cd -P "$bin_dir" && pwd)
case "$bin_dir" in
    "$prefix"/bin) ;;
    *) echo "Resolved binary directory escaped install prefix" >&2; exit 1 ;;
esac
destination="$bin_dir/fubby"
if [ -L "$destination" ]; then
    echo "Refusing to replace symlink: $destination" >&2
    exit 1
fi
temporary=$(mktemp "$bin_dir/.fubby.install.XXXXXX")
cleanup() { rm -f "$temporary"; }
trap cleanup 0 HUP INT TERM
cp "$source_binary" "$temporary"
chmod 755 "$temporary"
mv -f "$temporary" "$destination"
trap - 0 HUP INT TERM
echo "Installed Fubby to $destination"
echo "Add this to PATH if needed: export PATH=\"$bin_dir:\$PATH\""
