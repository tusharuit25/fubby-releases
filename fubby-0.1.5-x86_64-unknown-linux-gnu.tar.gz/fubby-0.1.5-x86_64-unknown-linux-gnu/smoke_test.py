#!/usr/bin/env python3
"""Checkout-independent smoke test for an extracted Fubby preview bundle.

Uses only Python's standard library plus the supplied Fubby executable. The
script is intentionally bundled so an installed preview can be tested after
the source checkout is unavailable.
"""

from __future__ import annotations

import concurrent.futures
import http.client
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import time


def run(binary: Path, args: list[str], cwd: Path, timeout: int = 30) -> str:
    result = subprocess.run(
        [str(binary), *args],
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if result.returncode:
        raise RuntimeError(
            f"command failed ({result.returncode}): {binary} {' '.join(args)}\n"
            f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        )
    return result.stdout


def request(port: int, method: str, path: str, body: dict | None = None):
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    payload = None if body is None else json.dumps(body)
    headers = {"Content-Type": "application/json"} if payload is not None else {}
    try:
        connection.request(method, path, body=payload, headers=headers)
        response = connection.getresponse()
        data = response.read()
        return response.status, response.getheader("Content-Type", ""), data
    finally:
        connection.close()


def wait_server(process: subprocess.Popen, marker: Path, port: int) -> None:
    deadline = time.monotonic() + 20
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(f"server exited during startup: {process.returncode}")
        if marker.exists():
            return
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                return
        except OSError:
            time.sleep(0.05)
    raise TimeoutError("Snow server did not start listening")


def main() -> int:
    if len(sys.argv) != 3:
        print("usage: python3 smoke_test.py <installed-fubby> <starter-project>", file=sys.stderr)
        return 2
    binary = Path(sys.argv[1]).resolve(strict=True)
    starter = Path(sys.argv[2]).resolve(strict=True)
    app_template = starter / "app"
    if not binary.is_file() or not os.access(binary, os.X_OK):
        raise ValueError("Fubby path must be an executable file")
    if not (app_template / "fubby.toml").is_file():
        raise ValueError("starter project is missing app/fubby.toml")

    version = run(binary, ["--version"], Path.cwd())
    if not all(line for line in version.splitlines()) or "target: " not in version:
        raise AssertionError(f"incomplete build information: {version}")
    print("CLI_VERSION: PASS")

    with tempfile.TemporaryDirectory(prefix="fubby-preview-smoke-") as temporary:
        root = Path(temporary)
        copied_starter = root / "starter-project"
        shutil.copytree(starter, copied_starter)
        app = copied_starter / "app"
        (app / "preview.db").unlink(missing_ok=True)
        output = run(binary, ["init", str(root / "initialized")], root)
        assert "Created" in output
        assert (root / "initialized/src/main.fab").is_file()

        run(binary, ["pkg", "validate"], app)
        run(binary, ["pkg", "install"], app)
        listing = run(binary, ["pkg", "list"], app)
        assert "preview-kit" in listing
        run(binary, ["check", "src/main.fab"], app)
        tests = run(binary, ["shady", "test", "tests/preview_tests.fab"], app)
        assert "3 passed; 0 failed" in tests
        run(binary, ["shady", "fmt", "--check", "src"], app)
        run(binary, ["shady", "lint", "src"], app)
        print("STARTER_AND_TOOLS: PASS (init, Smokey validate/install/list, check, Shady test/fmt/lint)")

        # Ask the kernel for a free loopback port, then let Snow bind it.
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        marker = root / "stop.marker"
        env = {**os.environ, "FUBBY_NET_ALLOWLIST": "127.0.0.1"}
        server = subprocess.Popen(
            [
                str(binary), "snow", "serve", "src/main.fab", "--port", str(port),
                "--workers", "4", "--queue-capacity", "32", "--shutdown-file", str(marker),
            ],
            cwd=app,
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
        )
        try:
            wait_server(server, marker, port)
            for page in ("/", "/about", "/runtime"):
                status, content_type, body = request(port, "GET", page)
                assert status == 200 and "text/html" in content_type and b"<html" in body
            status, content_type, body = request(port, "GET", "/assets/style.css")
            assert status == 200 and "text/css" in content_type and b"body" in body
            print("BROWSER_PAGES_AND_ASSETS: PASS")

            status, _ctype, body = request(port, "POST", "/api/notes", {"title": "  Preview note  "})
            assert status == 201
            note = json.loads(body)
            note_id = note["id"]
            assert note["title"] == "Preview note"
            status, _ctype, body = request(port, "GET", f"/api/notes/{note_id}")
            assert status == 200 and json.loads(body)["title"] == "Preview note"
            status, _ctype, body = request(port, "PATCH", f"/api/notes/{note_id}", {"title": "Updated"})
            assert status == 200
            status, _ctype, body = request(port, "GET", "/api/notes")
            assert status == 200 and any(item["title"] == "Updated" for item in json.loads(body))
            status, _ctype, _body = request(port, "DELETE", f"/api/notes/{note_id}")
            assert status == 204
            print("SQLITE_CRUD: PASS")

            def probe_request(index: int):
                token = f"isolated-{index:03}"
                status, _ctype, response = request(port, "GET", f"/api/probe/{token}")
                result = json.loads(response)
                if status != 200 or result.get("token") != token:
                    raise AssertionError(f"request context crossed for {token}: {status} {result}")
                return token

            with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
                tokens = list(pool.map(probe_request, range(48)))
            assert len(set(tokens)) == 48
            print("CONCURRENT_REQUEST_ISOLATION: PASS (48 unique requests; 12 clients)")

            run(binary, ["snow", "stop", str(marker)], app)
            try:
                server.wait(timeout=15)
            except subprocess.TimeoutExpired as error:
                server.kill()
                raise TimeoutError("Snow server did not shut down gracefully") from error
            assert server.returncode == 0, f"Snow server exit status: {server.returncode}"
            print("GRACEFUL_SHUTDOWN: PASS")
        finally:
            if server.poll() is None:
                server.terminate()
                try:
                    server.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    server.kill()
                    server.wait(timeout=5)
    print("CHECKOUT_INDEPENDENT_SMOKE: PASS")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AssertionError, OSError, RuntimeError, TimeoutError, ValueError, subprocess.SubprocessError) as error:
        print(f"smoke_test: {error}", file=sys.stderr)
        raise SystemExit(1)
