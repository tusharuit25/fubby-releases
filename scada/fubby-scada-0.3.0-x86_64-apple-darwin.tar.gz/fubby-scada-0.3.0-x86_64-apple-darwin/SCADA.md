# The SCADA build of Fubby

This is Fubby 0.3.0 with three more Moon modules for industrial devices: `moon.serial`,
`moon.opcua` and `moon.bacnet`. Everything else is the same as the standard download, so
install it in its place. [FubbyScada](https://github.com/tusharuit25/fubbyscada) uses all
three.

OpenSSL, which OPC UA needs, is built into the binary, so nothing else needs installing. The
build is for macOS on Intel and Linux on x86-64. There's no Windows SCADA build, because the
serial module works only on macOS and Linux.

Each module reaches only the devices you list:

| Setting | For |
| --- | --- |
| `FUBBY_SERIAL_ALLOWLIST` | Serial device paths, such as `/dev/ttyUSB0`, separated by `:`. Symbolic links are resolved first. |
| `FUBBY_NET_ALLOWLIST` | OPC UA and BACnet hosts, as for Moon's HTTP and TCP clients |
| `FUBBY_OPCUA_PKI_DIR` | The folder of OPC UA certificates, with `trusted` and `rejected` inside |

`moon.serial.available()`, `moon.opcua.available()` and `moon.bacnet.available()` return
`true` in this build and `false` in the standard one.

## moon.serial

```fubby
func main() {
    let port = moon.serial.open("/dev/ttyUSB0", {"baud_rate": 19200, "timeout_ms": 500})
    port.write([1, 3, 0, 0, 0, 1, 132, 10])
    print(json_encode(port.read_exact(7)))
    port.close()
}
```

| Option | Default | Values |
| --- | --- | --- |
| `baud_rate` | 9600 | 50 to 230400, the standard rates |
| `data_bits` | 8 | 5, 6, 7, 8 |
| `stop_bits` | 1 | 1, 2 |
| `parity` | `"none"` | `"none"`, `"even"`, `"odd"` |
| `flow_control` | `"none"` | `"none"`, `"software"`, `"hardware"` |
| `timeout_ms` | 1000 | 1 to 30000, for each read or write |
| `exclusive` | true | Asks the system for exclusive access |

A port has these methods:
- `read(max_bytes)` returns the bytes that arrived first.
- `read_exact(count)` waits for `count` bytes, within one deadline.
- `write(bytes)` sends bytes.
- `discard_input()` drops received bytes that haven't been read.
- `set_rts(on)` and `set_dtr(on)` set the control lines.
- `is_open()` says whether this handle is open, and `close()` closes it.

Bytes are lists of integers from 0 to 255. Reads and writes return `timed_out` and
`disconnected` alongside the bytes, and keep partial data. A port closes itself when nothing
refers to it any more.

## moon.opcua

```fubby
func main() {
    let endpoint = "opc.tcp://plc.example:4840"
    print(moon.opcua.read(endpoint, "ns=2;s=Pump1.Speed", {}))
    moon.opcua.write(endpoint, "ns=2;s=Pump1.Setpoint", 42.5, {})
}
```

- **Values:** reads and writes the Value attribute of one node, as a Boolean, number or
  String, with an anonymous identity.
- **Sessions:** each call opens its own session.
- **Security:** the `security` option is `Basic256Sha256` (the default),
  `Aes128_Sha256_RsaOaep`, `Aes256_Sha256_RsaPss`, or `None` for servers deliberately left
  unsecured.
- **Server certificates:** a server's certificate must be in `trusted` under
  `FUBBY_OPCUA_PKI_DIR`. One that isn't is refused and saved under `rejected`. Once you've
  checked it, move it to `trusted`.
- **Not yet supported:** subscriptions, browsing, historical access, user names and arrays.
- **Timeouts:** the client library can't bound how long a connection takes, so an
  unresponsive server can hold a call longer than Fubby's other limits.

## moon.bacnet

```fubby
func main() {
    // Present value (85) of analog input 1 (object type 0).
    print(moon.bacnet.read_property("192.0.2.50", 47808, 0, 1, 85, {}))
    moon.bacnet.write_property("192.0.2.50", 47808, 1, 3, 85, 21.5, {"priority": 8})
}
```

- **Calls:** ReadProperty and WriteProperty over BACnet/IP, to a unicast IPv4 address listed
  in `FUBBY_NET_ALLOWLIST`.
- **Identifiers:** object types and properties are their numeric identifiers, and instances
  run from 0 to 4,194,303.
- **Values:** Boolean, integer, Real, Double and CharacterString.
- **Options:** `timeout_ms` (3000 by default, up to 30000) bounds the wait for a reply, and
  `priority` (1 to 16) sets a write's priority.
- **Lost replies:** a write that times out may or may not have happened.
- **Not yet supported:** discovery, routed networks, COV and BACnet Secure Connect.

## Licenses

The SCADA build adds open-source components to Fubby's, among them OpenSSL and the opcua
package. Each one and its license is listed in `THIRD_PARTY_NOTICES.txt`.
