# Fubby Developer Preview troubleshooting

The release bundle includes `smoke_test.py`. See `PREVIEW_INSTALL.md` for the
checkout-independent smoke command. It exercises the installed executable
using only the extracted starter and standard Python libraries, but runs on
the current host and is not a physical clean-machine or cross-platform test.

## `fubby: command not found`

The installer defaults to `$HOME/.local/bin`. Add this directory to the
current shell or log in again:

```sh
export PATH="$HOME/.local/bin:$PATH"
```

## `bad CPU type`, `Exec format error`, or a target mismatch

Run `fubby --version` and compare its `target` line with the release manifest.
The verified local package in this preview targets `x86_64-apple-darwin`.
Installing an archive for another architecture or operating system will not
work. Cross-target archives are labeled unverified until smoke-tested natively.
Apple Silicon and Linux are not established as supported by an Intel macOS run.
On Linux, the minimum glibc version has not been tested or declared.

## macOS warns that the binary cannot be verified

The preview binary is unsigned and not notarized. Do not bypass Gatekeeper for
an artifact without trusted provenance. Publisher authentication and signed
build provenance are not implemented.

## Checksum verification fails

Do not extract or run the archive. Re-copy or re-download the archive and its
trusted checksum file, then verify again. A checksum file downloaded through
the same untrusted channel is not cryptographic publisher authentication.

## Installer rejects the prefix

Install without elevation under a user-owned directory, for example:

```sh
./install.sh --prefix "$HOME/.local"
```

The installer intentionally rejects system directories, symlinked `bin`
directories, and a symlink at the destination. Remove or safely rename an
existing conflicting symlink yourself before retrying. It never invokes
`sudo`.

## Smokey reports a missing dependency

Run `fubby pkg validate`, then `fubby pkg install` from `starter-project/app`.
The starter uses a local path package, so the entire `starter-project`
directory must remain together. Installation writes `fubby.lock` and
`.fubby/packages/` into that app directory.

## Snow cannot bind or the browser cannot connect

The starter defaults to local loopback. Use `--port 0` to request an available
port, and read the `Snow listening on ...` line. Check for another process
using port 8080 and local firewall restrictions. This preview does not include
TLS or authentication and should not be exposed to an untrusted network.
The packaged smoke check requires working local loopback sockets; run it where
localhost binding is permitted.

## Packaged smoke check fails

Confirm Python 3 is available and pass the installed executable and the
matching archive's `starter-project` directory. The test copies the project to
a temporary directory, installs its local path dependency, and starts Snow on
loopback. A busy port, unavailable loopback, or incompatible target can fail
the check. Run it from `/tmp` to avoid confusion with a source checkout.

## Building from source fails

Use the pinned Rust 1.98.1 toolchain and run Cargo from the private source
checkout with `--locked`. First confirm that the platform target and linker are
installed. Linux GNU builds depend on the host's compatible glibc runtime.
Binary installation does not require Rust or Cargo.
