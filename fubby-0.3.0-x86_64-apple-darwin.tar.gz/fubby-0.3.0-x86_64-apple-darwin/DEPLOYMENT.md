# Deploying a Fubby web app

This guide puts a Snow app on a Linux server, behind nginx or Caddy. The proxy handles
HTTPS; Snow listens only on 127.0.0.1 and runs as a systemd service.

The example is `examples/web_app`, a small notes site with sign-in, sessions, forms and
uploads. Its configs are in `deploy/`. Both come with this guide in the Fubby download, so
run the commands below from the folder you unpacked the Linux download into.

The configs are tested as written, with only the host names, ports, certificate paths and
folders changed:
- The app runs behind nginx and Caddy over HTTPS.
- The unit runs as a real service on Ubuntu 24.04 (systemd 255). The tests check that the
  app works inside the unit's sandbox, restarts after a crash and stops cleanly.
  `systemd-analyze security` rates the unit 1.3, "OK".

Fubby is a developer preview, so check the [security notes](#what-snow-does-and-doesnt)
before you rely on it.

You need:
- A Linux server with systemd. These steps were tested on Ubuntu 24.04.
- The `fubby` binary for Linux x86-64, which needs glibc 2.34 or later.
- nginx or Caddy, and a domain name pointing at the server.

## 1. Lay out the app

The app gets its own user, which can write only its data and upload folders. Its code
belongs to root, so the running app can't change it.

```sh
sudo install -m 755 bin/fubby /usr/local/bin/fubby
sudo useradd --system --home-dir /srv/fubby-app --no-create-home --shell /usr/sbin/nologin fubby-app
sudo mkdir -p /srv/fubby-app/data/attachments /srv/fubby-app/data/backups /srv/fubby-app/uploads
sudo cp examples/web_app/app.fab examples/web_app/setup.fab examples/web_app/backup.fab /srv/fubby-app/
sudo chown -R fubby-app:fubby-app /srv/fubby-app/data /srv/fubby-app/uploads
```

Make the database and the first user:

```sh
cd /srv/fubby-app
sudo -u fubby-app env FUBBY_FS_ROOT=/srv/fubby-app NOTES_USER=ann NOTES_PASSWORD='a long passphrase' fubby run setup.fab
```

## 2. Make the secret

Snow encrypts session cookies with a secret only the server knows. Make one, and keep it
readable only by root; systemd passes it to the app.

```sh
sudo mkdir -p /etc/fubby-app
fubby snow new-secret | sudo tee /etc/fubby-app/snow-secret > /dev/null
sudo chmod 600 /etc/fubby-app/snow-secret
```

Snow refuses to start if every user on the server can read the file.

To change the secret without logging anyone out:
1. Put a new secret on the first line and keep the old one on the second. The first line
   encrypts new cookies, and every line opens existing ones.
2. Restart the service.
3. After `--session-max-s` (30 days by default), delete the old line and restart again.

Replacing the secret outright logs everyone out. That is also how to end every session at
once, for example if the secret may have leaked.

## 3. Run it as a service

Install the unit, then start it:

```sh
sudo cp deploy/fubby-app.service /etc/systemd/system/fubby-app.service
sudo systemctl daemon-reload
sudo systemctl enable --now fubby-app
curl -fsS http://127.0.0.1:8080/healthz
```

`deploy/fubby-app.service`:

```ini
# systemd service for a Fubby web app behind nginx or Caddy. DEPLOYMENT.md explains each
# part. Install it as /etc/systemd/system/fubby-app.service, then:
#   sudo systemctl daemon-reload && sudo systemctl enable --now fubby-app
[Unit]
Description=Fubby web app (Snow)
After=network.target

[Service]
Type=simple
User=fubby-app
Group=fubby-app
WorkingDirectory=/srv/fubby-app
# The app may read and write files only inside its own folder.
Environment=FUBBY_FS_ROOT=/srv/fubby-app
# systemd hands the secret to the service in a private folder, %d, readable only by it.
LoadCredential=snow-secret:/etc/fubby-app/snow-secret
ExecStart=/usr/local/bin/fubby snow serve app.fab --host 127.0.0.1 --port 8080 --workers 4 --trust-proxy 127.0.0.1,::1 --hsts --access-log json --health-path /healthz --secret-file %d/snow-secret --max-upload-bytes 10485760 --upload-dir /srv/fubby-app/uploads --drain-timeout-ms 30000
# SIGTERM lets accepted requests finish; give that longer than --drain-timeout-ms.
KillSignal=SIGTERM
TimeoutStopSec=40
Restart=on-failure
RestartSec=2

# The service can't gain privileges, sees the system read-only, and may write only here.
NoNewPrivileges=yes
ProtectSystem=strict
ReadWritePaths=/srv/fubby-app/data /srv/fubby-app/uploads
ProtectHome=yes
PrivateTmp=yes
PrivateDevices=yes
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectControlGroups=yes
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX
RestrictNamespaces=yes
CapabilityBoundingSet=
PrivateUsers=yes
ProtectClock=yes
ProtectHostname=yes
ProtectKernelLogs=yes
ProtectProc=invisible
RestrictRealtime=yes
RestrictSUIDSGID=yes
RemoveIPC=yes
LockPersonality=yes
MemoryDenyWriteExecute=yes
SystemCallArchitectures=native
SystemCallFilter=@system-service
SystemCallErrorNumber=EPERM
UMask=0077

[Install]
WantedBy=multi-user.target
```

What the Snow options do:

| Option | Why |
| --- | --- |
| `--host 127.0.0.1 --port 8080` | Only the proxy, on the same machine, can reach Snow. |
| `--workers 4` | Requests handled at once; up to 32. |
| `--trust-proxy 127.0.0.1,::1` | Believe the proxy's `X-Forwarded-*` headers, and nobody else's. Snow then knows the visitor's address and that they used HTTPS. |
| `--hsts` | Tell browsers to use HTTPS for this site from now on. |
| `--access-log json` | One JSON line per request, for `journalctl`. |
| `--health-path /healthz` | Answers `{"status":"ok"}` without running app code. |
| `--secret-file %d/snow-secret` | Turns on sessions and CSRF checks. |
| `--max-upload-bytes 10485760` | Allows uploads of up to 10 MiB. Without it, uploads are refused. |
| `--upload-dir /srv/fubby-app/uploads` | Where uploads wait until their request ends. |
| `--drain-timeout-ms 30000` | How long a stop waits for requests already accepted. |

## 4. Put a proxy in front

Use one of the two.

### nginx

Get a certificate, for example with `sudo certbot certonly --nginx -d example.com`. Then
copy the site config, change `example.com` and the certificate paths, and reload:

```sh
sudo cp deploy/nginx.conf /etc/nginx/conf.d/fubby-app.conf
sudo nginx -t && sudo systemctl reload nginx
```

`deploy/nginx.conf`:

```nginx
# nginx in front of a Fubby web app. DEPLOYMENT.md explains each part. Put it in
# /etc/nginx/sites-available/fubby-app (or conf.d/fubby-app.conf), replace example.com and
# the certificate paths, then: sudo nginx -t && sudo systemctl reload nginx

# Ten sign-in attempts a minute per visitor, with a small burst.
limit_req_zone $binary_remote_addr zone=fubby_login:10m rate=10r/m;

upstream fubby_app {
    server 127.0.0.1:8080;
}

server {
    listen 80;
    listen [::]:80;
    server_name example.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    listen [::]:443 ssl;
    server_name example.com;
    ssl_certificate /etc/letsencrypt/live/example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/example.com/privkey.pem;

    # Matches Snow's --max-upload-bytes.
    client_max_body_size 10m;

    # Snow believes these only because it trusts 127.0.0.1 (--trust-proxy).
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header X-Forwarded-Host $host;
    proxy_set_header X-Request-Id $request_id;
    proxy_read_timeout 60s;

    location = /login {
        limit_req zone=fubby_login burst=5 nodelay;
        proxy_pass http://fubby_app;
    }

    location / {
        proxy_pass http://fubby_app;
    }
}
```

### Caddy

Caddy gets and renews the certificate itself. Change `example.com`, put this in
`/etc/caddy/Caddyfile`, and run `sudo systemctl reload caddy`.

`deploy/Caddyfile`:

```caddy
# Caddy in front of a Fubby web app. DEPLOYMENT.md explains each part. Replace
# example.com; Caddy gets and renews the HTTPS certificate itself. Then: caddy reload
example.com {
	# Matches Snow's --max-upload-bytes.
	request_body {
		max_size 10MB
	}
	# Caddy sends X-Forwarded-For, -Proto and -Host itself. Snow believes them only because
	# it trusts 127.0.0.1 (--trust-proxy).
	reverse_proxy 127.0.0.1:8080 {
		header_up X-Request-Id {http.request.uuid}
	}
}
```

Caddy has no built-in rate limit. Use nginx, or a Caddy rate-limit plugin, if sign-in
attempts need limiting beyond what your app does.

## 5. Close everything else

Only SSH, HTTP and HTTPS need to be reachable. Snow already listens on 127.0.0.1 only.

```sh
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

## 6. Logs, health and backups

Snow writes one JSON line per request, plus warnings, errors, and the service starting and
stopping. Each line has `time`, `level`, `component`, `event` and the details:

```sh
journalctl -u fubby-app -f -o cat
journalctl -u fubby-app -o cat | jq 'select(.level == "error")'
```

Query strings aren't logged, because they can hold tokens. Successful health checks aren't
logged either, so a monitor can call `/healthz` every few seconds. When every worker is
busy, `/healthz` answers 503.

To back up the database while the app runs, run `backup.fab` every day, for example from
cron or a systemd timer:

```sh
cd /srv/fubby-app && sudo -u fubby-app env FUBBY_FS_ROOT=/srv/fubby-app fubby run backup.fab
```

Each backup is checked, and named after the time, so none is ever replaced. Copy them off
the server too.

## 7. Upgrades

Unpack the new download, and from its folder replace the binary, then restart:

```sh
sudo install -m 755 bin/fubby /usr/local/bin/fubby
sudo systemctl restart fubby-app
```

Stopping sends SIGTERM. Snow stops accepting connections, lets accepted requests finish
for up to `--drain-timeout-ms`, then exits. Requests that arrive while it restarts get a
502 from the proxy. If the app crashes, systemd starts it again after 2 seconds.

## What Snow does, and doesn't

Snow does:
- **Sessions:** encrypted, tamper-proof session cookies, which are `HttpOnly`,
  `SameSite=Lax`, and `Secure` over HTTPS.
- **CSRF:** every form or request that changes something must carry its session's CSRF
  token.
- **Headers:** `X-Frame-Options`, `Referrer-Policy`, `Cross-Origin-Opener-Policy`, a
  framing `Content-Security-Policy`, `nosniff`, and HSTS with `--hsts`.
- **Passwords:** argon2id hashing.
- **Limits:** time limits on reading, handling and writing each request, size limits on
  bodies and uploads, and uploads saved only where `FUBBY_FS_ROOT` allows.

Snow doesn't:
- **Encryption on the wire:** HTTPS is the proxy's job.
- **Revoking one session:** a stolen session cookie stays valid until it expires, at most
  `--session-idle-s` after its last use (1 day by default). Signing out clears it in that
  browser only. Changing the secret ends every session.
- **Load:** rate limiting, compression and caching belong to the proxy.
- **Untrusted code:** Fubby is not a sandbox. Run only code you trust.
