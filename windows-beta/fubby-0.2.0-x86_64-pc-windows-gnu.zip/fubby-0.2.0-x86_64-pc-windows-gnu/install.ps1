#Requires -Version 5.1
<#
.SYNOPSIS
Installs fubby.exe into a folder you own. It never needs administrator rights.

.PARAMETER Prefix
Where to install. Defaults to %LOCALAPPDATA%\Programs\Fubby. fubby.exe goes in its bin folder.

.PARAMETER NoPath
Don't add the bin folder to your user PATH.
#>
[CmdletBinding()]
param(
    [string]$Prefix = "",
    [switch]$NoPath
)
Set-StrictMode -Version 3
$ErrorActionPreference = "Stop"

function Test-Link([string]$Path) {
    $item = Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
    return ($null -ne $item) -and (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)
}

function Test-SystemPath([string]$Path) {
    $full = [IO.Path]::GetFullPath($Path).TrimEnd("\", "/")
    if (-not $full -or $full -match "^[A-Za-z]:$") {
        return $true
    }
    foreach ($name in "WINDIR", "ProgramFiles", "ProgramFiles(x86)", "ProgramData") {
        $system = [Environment]::GetEnvironmentVariable($name)
        if ($system) {
            $system = [IO.Path]::GetFullPath($system).TrimEnd("\", "/")
            if ($full -ieq $system -or $full.StartsWith($system + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
                return $true
            }
        }
    }
    return $false
}

if (-not $Prefix) { $Prefix = $env:FUBBY_PREFIX }
if (-not $Prefix) {
    if (-not $env:LOCALAPPDATA) { throw "LOCALAPPDATA is not set. Pass -Prefix with a folder you own." }
    $Prefix = Join-Path (Join-Path $env:LOCALAPPDATA "Programs") "Fubby"
}
$Prefix = [IO.Path]::GetFullPath($Prefix)
if (Test-SystemPath $Prefix) { throw "Refusing unsafe install prefix: $Prefix" }
if (Test-Link $Prefix) { throw "Refusing symlink install prefix: $Prefix" }

$source = Join-Path (Join-Path $PSScriptRoot "bin") "fubby.exe"
if ((Test-Link $source) -or -not (Test-Path -LiteralPath $source -PathType Leaf)) {
    throw "Bundle executable is missing or is a symlink: $source"
}

$binDir = Join-Path $Prefix "bin"
if (Test-Link $binDir) { throw "Refusing symlink install directory: $binDir" }
New-Item -ItemType Directory -Path $binDir -Force | Out-Null
$destination = Join-Path $binDir "fubby.exe"
if (Test-Link $destination) { throw "Refusing to replace symlink: $destination" }

# Copy beside the destination first, so a failed copy can't leave a broken install.
$temporary = Join-Path $binDir (".fubby.install." + [Guid]::NewGuid().ToString("N"))
try {
    Copy-Item -LiteralPath $source -Destination $temporary
    Move-Item -LiteralPath $temporary -Destination $destination -Force
} finally {
    Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue
}
Write-Output "Installed Fubby to $destination"

$onWindows = [Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT
if ($NoPath -or -not $onWindows) {
    Write-Output "Add this folder to PATH if needed: $binDir"
    return
}
$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
$entries = @(if ($userPath) { $userPath -split ";" | Where-Object { $_ } })
if ($entries -inotcontains $binDir) {
    [Environment]::SetEnvironmentVariable("Path", (($entries + $binDir) -join ";"), "User")
    Write-Output "Added $binDir to your user PATH. Open a new terminal to use fubby."
}
$env:Path = "$env:Path;$binDir"
