#Requires -Version 5.1
<#
.SYNOPSIS
Removes fubby.exe and its PATH entry. Your projects and data are never touched.

.PARAMETER Prefix
The folder Fubby was installed in, if you chose one when installing.
#>
[CmdletBinding()]
param(
    [string]$Prefix = ""
)
Set-StrictMode -Version 3
$ErrorActionPreference = "Stop"

function Test-Link([string]$Path) {
    $item = Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
    return ($null -ne $item) -and (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)
}

if (-not $Prefix) { $Prefix = $env:FUBBY_PREFIX }
if (-not $Prefix) {
    if (-not $env:LOCALAPPDATA) { throw "LOCALAPPDATA is not set. Pass -Prefix with the install folder." }
    $Prefix = Join-Path (Join-Path $env:LOCALAPPDATA "Programs") "Fubby"
}
$Prefix = [IO.Path]::GetFullPath($Prefix)
if (Test-Link $Prefix) { throw "Refusing symlink install prefix: $Prefix" }
$binDir = Join-Path $Prefix "bin"
if (Test-Link $binDir) { throw "Refusing symlink install directory: $binDir" }
$destination = Join-Path $binDir "fubby.exe"
if (Test-Link $destination) { throw "Refusing to remove symlink: $destination" }

if (Test-Path -LiteralPath $destination -PathType Leaf) {
    Remove-Item -LiteralPath $destination -Force
    Write-Output "Removed $destination"
} else {
    Write-Output "Fubby is not installed at $destination"
}

if ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT) {
    $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
    if ($userPath) {
        $entries = @($userPath -split ";" | Where-Object { $_ -and ($_ -ine $binDir) })
        [Environment]::SetEnvironmentVariable("Path", ($entries -join ";"), "User")
    }
}
